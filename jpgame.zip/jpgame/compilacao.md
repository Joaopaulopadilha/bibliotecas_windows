
# JPD (DLL)
g++ -shared -o bibliotecas/jpgame/jpgame.jpd bibliotecas/jpgame/jpgame.cpp -ld3d11 -O3