#include <vector>
#include <variant>
#include <memory>
#include <string>
#include "janela.hpp"

// Forward declaration
struct Instancia;
using Var = std::variant<std::string, int, double, bool, std::shared_ptr<Instancia>>;

// === HELPERS ===
static int get_int(const Var& v) {
    if (auto* i = std::get_if<int>(&v)) return *i;
    if (auto* d = std::get_if<double>(&v)) return (int)*d;
    return 0;
}

static std::string get_str(const Var& v) {
    if (auto* s = std::get_if<std::string>(&v)) return *s;
    if (auto* i = std::get_if<int>(&v)) return std::to_string(*i);
    if (auto* d = std::get_if<double>(&v)) return std::to_string(*d);
    if (auto* b = std::get_if<bool>(&v)) return *b ? "true" : "false";
    return "";
}

// === EXPORTS PARA JPLANG ===
extern "C" {

// Cria e inicia janela em thread separada
// jpgame.janela("titulo", largura, altura) -> retorna 1 se sucesso
Var jpgame_janela(const std::vector<Var>& args) {
    if (args.size() < 3) return 0;
    
    std::string titulo = get_str(args[0]);
    int largura = get_int(args[1]);
    int altura = get_int(args[2]);
    
    return criarJanela(titulo, largura, altura);
}

// Define cor de fundo da janela (RGB 0-255)
// jpgame.janela_cor_fundo(janela, r, g, b)
Var jpgame_janela_cor_fundo(const std::vector<Var>& args) {
    if (args.size() < 4) return false;
    
    // args[0] é o ID da janela (ignorado por enquanto, só temos uma)
    int r = get_int(args[1]);
    int g = get_int(args[2]);
    int b = get_int(args[3]);
    
    return janelaCorFundo(r, g, b);
}

// Define imagem de fundo da janela
// jpgame.janela_imagem_fundo(janela, "caminho/imagem.png")
Var jpgame_janela_imagem_fundo(const std::vector<Var>& args) {
    if (args.size() < 2) return false;
    
    // args[0] é o ID da janela (ignorado por enquanto, só temos uma)
    std::string caminho = get_str(args[1]);
    
    return janelaImagemFundo(caminho);
}

// Processa eventos e mantém a janela rodando
// jpgame.rodar(janela) -> retorna true se ainda está ativa
Var jpgame_rodar(const std::vector<Var>& args) {
    return janelaRodando();
}

// Fecha a janela
// jpgame.fechar(janela)
Var jpgame_fechar(const std::vector<Var>& args) {
    return fecharJanela();
}

} // extern "C"